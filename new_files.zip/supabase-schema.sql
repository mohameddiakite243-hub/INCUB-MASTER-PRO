-- Incub'Master — schéma de la base de données publique (Supabase)
-- Peut être exécuté plusieurs fois sans erreur (tables, policies et fonctions rejouables).

-- ==================================================================
-- Statistiques communes de réussite d'incubation
-- ==================================================================
-- Protection contre les faux résultats :
--  * plus d'écriture ni de lecture directe : tout passe par 3 fonctions contrôlées ;
--  * un seul vote par couvée et par contributeur (un renvoi met à jour, il n'ajoute pas) ;
--  * seules les espèces connues et des valeurs plausibles sont acceptées ;
--  * plafonds par contributeur et plafond global ;
--  * le résumé public utilise la MÉDIANE (robuste aux valeurs extrêmes) et indique le
--    nombre d'éleveurs distincts.
-- Limite honnête : sans compte ni vérification, un attaquant déterminé qui change
-- d'identité peut toujours ajouter des lignes ; ces mesures en réduisent l'impact.

create table if not exists public.stats (
  id uuid primary key default gen_random_uuid(),
  espece text not null,
  nb integer not null check (nb > 0),
  eclos integer not null check (eclos >= 0 and eclos <= nb),
  stock integer default 0,
  type text default 'automatique',
  ts bigint default (extract(epoch from now()) * 1000)::bigint
);

-- Nouvelles colonnes (ajoutées sans toucher aux anciennes lignes)
alter table public.stats add column if not exists contributor text;  -- identifiant aléatoire d'un appareil
alter table public.stats add column if not exists lot_key text;      -- identifiant de la couvée
create unique index if not exists stats_contributor_lot_uidx on public.stats (contributor, lot_key);
create index if not exists stats_espece_idx on public.stats (espece);

alter table public.stats enable row level security;

-- Fermeture de l'accès direct (anciennes règles supprimées, aucune règle de remplacement)
drop policy if exists "Lecture publique" on public.stats;
drop policy if exists "Ajout public" on public.stats;
revoke all on public.stats from anon, authenticated;

-- Les anciennes lignes (sans contributeur) restent en base mais ne comptent plus dans le résumé.
-- Pour les supprimer définitivement : delete from public.stats where contributor is null;

create or replace function public.stats_submit(
  p_contributor text, p_lot_key text, p_espece text,
  p_nb integer, p_eclos integer, p_stock integer default 0, p_type text default 'automatique'
) returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  existing boolean;
  nrows bigint;
  mine integer;
  recent integer;
begin
  if p_contributor is null or p_contributor !~ '^[0-9a-f]{32}$' then raise exception 'contributeur invalide'; end if;
  if p_lot_key is null or length(p_lot_key) < 1 or length(p_lot_key) > 64 then raise exception 'couvée invalide'; end if;
  if p_espece is null or not (p_espece = any (array['Poule','Pintade','Dindon','Canard','Oie','Pigeon','Caille'])) then
    raise exception 'espèce non partagée';
  end if;
  if p_nb is null or p_nb < 5 or p_nb > 5000 then raise exception 'nombre d''œufs hors limites'; end if;
  if p_eclos is null or p_eclos < 0 or p_eclos > p_nb then raise exception 'résultat invalide'; end if;
  if coalesce(p_stock, 0) < 0 or coalesce(p_stock, 0) > 30 then raise exception 'stockage hors limites'; end if;
  if p_type is null or p_type not in ('automatique', 'manuelle') then raise exception 'type invalide'; end if;

  -- Plafond global approximatif (évite de remplir la base)
  select greatest(reltuples, 0)::bigint into nrows from pg_class where oid = 'public.stats'::regclass;
  if nrows > 500000 then raise exception 'service saturé'; end if;

  -- Plafonds par contributeur : seulement pour les NOUVELLES couvées (les corrections restent libres)
  select exists (select 1 from public.stats where contributor = p_contributor and lot_key = p_lot_key) into existing;
  if not existing then
    select count(*) into mine from public.stats where contributor = p_contributor;
    select count(*) into recent from public.stats
      where contributor = p_contributor and ts > (extract(epoch from now()) * 1000)::bigint - 86400000;
    if mine >= 500 then raise exception 'limite de couvées atteinte'; end if;
    if recent >= 60 then raise exception 'trop d''envois en 24 h'; end if;
  end if;

  insert into public.stats (contributor, lot_key, espece, nb, eclos, stock, type, ts)
  values (p_contributor, p_lot_key, p_espece, p_nb, p_eclos, coalesce(p_stock, 0), p_type,
          (extract(epoch from now()) * 1000)::bigint)
  on conflict (contributor, lot_key) do update
    set espece = excluded.espece, nb = excluded.nb, eclos = excluded.eclos,
        stock = excluded.stock, type = excluded.type, ts = excluded.ts;
end;
$$;

create or replace function public.stats_withdraw(p_contributor text, p_lot_key text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if p_contributor is null or p_contributor !~ '^[0-9a-f]{32}$' then raise exception 'contributeur invalide'; end if;
  delete from public.stats where contributor = p_contributor and lot_key = p_lot_key;
end;
$$;

create or replace function public.stats_summary()
returns table (espece text, n integer, contributors integer, median numeric, trimmed_mean numeric)
language sql
stable
security definer
set search_path = public
as $$
  with r as (
    select s.espece, s.contributor, s.eclos::numeric * 100 / s.nb as rate
    from public.stats s
    where s.contributor is not null and s.nb > 0
  ),
  b as (
    select r.espece,
           percentile_cont(0.1) within group (order by r.rate) as p10,
           percentile_cont(0.9) within group (order by r.rate) as p90
    from r group by r.espece
  )
  select r.espece,
         count(*)::int,
         count(distinct r.contributor)::int,
         round((percentile_cont(0.5) within group (order by r.rate))::numeric, 1),
         round((avg(r.rate) filter (where r.rate between b.p10 and b.p90))::numeric, 1)
  from r join b on b.espece = r.espece
  group by r.espece, b.p10, b.p90;
$$;

revoke all on function public.stats_submit(text, text, text, integer, integer, integer, text) from public;
revoke all on function public.stats_withdraw(text, text) from public;
revoke all on function public.stats_summary() from public;
grant execute on function public.stats_submit(text, text, text, integer, integer, integer, text) to anon, authenticated;
grant execute on function public.stats_withdraw(text, text) to anon, authenticated;
grant execute on function public.stats_summary() to anon, authenticated;


-- ==================================================================
-- Notifications push
-- ==================================================================

-- Un abonnement par appareil ayant accepté les notifications.
create table if not exists public.push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  endpoint text unique not null,
  p256dh text not null,
  auth text not null,
  created_at timestamptz default now()
);

-- Une ligne par rappel à envoyer (un par étape d'une couvée : mirage, éclosion...).
create table if not exists public.reminders (
  id uuid primary key default gen_random_uuid(),
  endpoint text not null references public.push_subscriptions(endpoint) on delete cascade,
  title text not null,
  body text not null,
  target_ts bigint not null,   -- date/heure d'envoi prévue, en millisecondes epoch
  sent boolean not null default false,
  created_at timestamptz default now()
);
create index if not exists reminders_due_idx on public.reminders (sent, target_ts);

alter table public.push_subscriptions enable row level security;
alter table public.reminders enable row level security;

-- L'app doit pouvoir s'abonner et programmer ses propres rappels.
drop policy if exists "Inscription push publique" on public.push_subscriptions;
create policy "Inscription push publique" on public.push_subscriptions
  for insert to anon with check (true);

drop policy if exists "Un appareil peut retirer son propre abonnement" on public.push_subscriptions;
create policy "Un appareil peut retirer son propre abonnement" on public.push_subscriptions
  for delete to anon using (true);

drop policy if exists "Programmer un rappel" on public.reminders;
create policy "Programmer un rappel" on public.reminders
  for insert to anon with check (true);

drop policy if exists "Annuler ses propres rappels" on public.reminders;
create policy "Annuler ses propres rappels" on public.reminders
  for delete to anon using (true);

-- Remarque : la Edge Function utilise la clé "service role" (jamais exposée au
-- navigateur), donc elle seule peut LIRE les abonnements/rappels et marquer
-- "sent = true" — ces deux actions ne sont volontairement ouvertes à personne
-- d'autre via l'API publique.


-- ==================================================================
-- Synchronisation des couvées entre appareils
-- ==================================================================
-- Principe : chaque éleveur dispose d'un « code de synchronisation » secret,
-- généré dans l'app. L'app n'envoie jamais ce code : elle envoie son empreinte
-- (SHA-256, 64 caractères hexadécimaux) appelée « bucket ». Tous les appareils
-- qui connaissent le même code retrouvent les mêmes couvées.
--
-- Sécurité : la table est fermée à l'API publique (RLS activé, aucune policy).
-- Seules les deux fonctions ci-dessous y accèdent, et uniquement pour le bucket
-- demandé. Sans le code, impossible de lire ou modifier les couvées d'un autre.

create table if not exists public.sync_lots (
  bucket text not null,
  lot_id text not null,
  data jsonb,                       -- contenu de la couvée (null si supprimée)
  updated_at bigint not null,       -- date de dernière modification, en millisecondes
  deleted boolean not null default false,
  primary key (bucket, lot_id)
);

alter table public.sync_lots enable row level security;
-- (volontairement aucune policy : pas d'accès direct à la table)

create or replace function public.sync_pull(p_bucket text)
returns table (lot_id text, data jsonb, updated_at bigint, deleted boolean)
language plpgsql
security definer
set search_path = public
as $$
begin
  if p_bucket is null or p_bucket !~ '^[0-9a-f]{64}$' then
    raise exception 'bucket invalide';
  end if;
  return query
    select s.lot_id, s.data, s.updated_at, s.deleted
    from public.sync_lots s
    where s.bucket = p_bucket;
end;
$$;

create or replace function public.sync_push(p_bucket text, p_rows jsonb)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  r jsonb;
  n integer := 0;
  total integer;
begin
  if p_bucket is null or p_bucket !~ '^[0-9a-f]{64}$' then
    raise exception 'bucket invalide';
  end if;
  if p_rows is null or jsonb_typeof(p_rows) <> 'array' or jsonb_array_length(p_rows) > 200 then
    raise exception 'lignes invalides';
  end if;

  for r in select value from jsonb_array_elements(p_rows) loop
    -- garde-fous : identifiant court, contenu raisonnable
    if coalesce(length(r->>'lot_id'), 0) = 0 or length(r->>'lot_id') > 64 then continue; end if;
    if length(coalesce((r->'data')::text, '')) > 20000 then continue; end if;

    insert into public.sync_lots (bucket, lot_id, data, updated_at, deleted)
    values (
      p_bucket,
      r->>'lot_id',
      case when coalesce((r->>'deleted')::boolean, false) then null else r->'data' end,
      (r->>'updated_at')::bigint,
      coalesce((r->>'deleted')::boolean, false)
    )
    on conflict (bucket, lot_id) do update
      set data = excluded.data,
          updated_at = excluded.updated_at,
          deleted = excluded.deleted
      where public.sync_lots.updated_at < excluded.updated_at;  -- la modification la plus récente gagne
    n := n + 1;
  end loop;

  select count(*) into total from public.sync_lots where bucket = p_bucket;
  if total > 1000 then
    raise exception 'limite de 1000 couvées atteinte';
  end if;
  return n;
end;
$$;

revoke all on function public.sync_pull(text) from public;
revoke all on function public.sync_push(text, jsonb) from public;
grant execute on function public.sync_pull(text) to anon, authenticated;
grant execute on function public.sync_push(text, jsonb) to anon, authenticated;
