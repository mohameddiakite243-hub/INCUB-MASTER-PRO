// IMPORTANT : changez CACHE (le numéro de version) à CHAQUE nouveau déploiement.
// C'est ce qui force les navigateurs déjà installés à détecter la mise à jour.
const CACHE = 'incubmaster-v23';

// Réception d'une notification push, même si l'app n'est pas ouverte.
self.addEventListener('push', e => {
  let data = { title: "Incub'Master PRO", body: 'Une couvée a besoin de vous.' };
  try { data = e.data.json(); } catch (err) {}
  e.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: 'https://cdn-icons-png.flaticon.com/512/415/415682.png',
      badge: 'https://cdn-icons-png.flaticon.com/512/415/415682.png',
      tag: data.title, // évite d'empiler plusieurs notifications identiques
    })
  );
});

// Au clic sur la notification : ouvrir l'app (ou la premettre au premier plan si déjà ouverte).
self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(clients => {
      for (const c of clients) { if ('focus' in c) return c.focus(); }
      if (self.clients.openWindow) return self.clients.openWindow('./index.html');
    })
  );
});
const ASSETS = ['index.html', 'manifest.json'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
  self.skipWaiting(); // active la nouvelle version immédiatement, sans attendre la fermeture des onglets
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(k => k !== CACHE).map(k => caches.delete(k)) // supprime les anciens caches (v1, etc.)
    ))
  );
  self.clients.claim(); // prend le contrôle des pages déjà ouvertes sans qu'elles aient à recharger deux fois
});

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;

  // La page elle-même (index.html) : toujours essayer le réseau en premier,
  // pour afficher la dernière version dès qu'il y a internet.
  // Le cache ne sert que de secours si l'appareil est hors ligne.
  if (e.request.mode === 'navigate' || e.request.destination === 'document') {
    e.respondWith(
      fetch(e.request)
        .then(res => {
          const copy = res.clone();
          caches.open(CACHE).then(c => c.put(e.request, copy));
          return res;
        })
        .catch(() => caches.match(e.request).then(c => c || caches.match('index.html')))
    );
    return;
  }

  // Les autres fichiers (manifest, icônes) : cache d'abord pour la rapidité,
  // avec mise à jour silencieuse en arrière-plan.
  e.respondWith(
    caches.match(e.request).then(cached => {
      const network = fetch(e.request).then(res => {
        if (res && res.status === 200) {
          const copy = res.clone();
          caches.open(CACHE).then(c => c.put(e.request, copy));
        }
        return res;
      }).catch(() => cached);
      return cached || network;
    })
  );
});

// Permet à la page d'afficher la version réellement installée (diagnostic des problèmes de cache).
self.addEventListener('message', e => {
  if (e.data && e.data.type === 'version' && e.ports && e.ports[0]) {
    e.ports[0].postMessage({ version: CACHE });
  }
});
